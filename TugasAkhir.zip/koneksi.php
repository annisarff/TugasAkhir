<?php 

$conn = mysqli_connect("localhost", "root", "" , "karyawan");

if(mysqli_connect_errno()){
    echo "Koneksi Gagal";
}
?>